var searchData=
[
  ['operator_3c_3c_0',['operator&lt;&lt;',['../class_student.html#ad6c1594342898f8fbd809c1c136f5439',1,'Student']]],
  ['operator_3e_3e_1',['operator&gt;&gt;',['../class_student.html#ab8f0b136ca5103f521e96185225583d9',1,'Student']]]
];
