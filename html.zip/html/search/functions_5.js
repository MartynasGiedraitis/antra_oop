var searchData=
[
  ['namu_5fdarbai_0',['namu_darbai',['../class_student.html#a995e1b78832fbc20634d0f5e8d933b82',1,'Student::namu_darbai()'],['../studentas_8h.html#a5627b41fdfe91330c95f8fb28e123b22',1,'namu_darbai():&#160;studentas.h']]]
];
