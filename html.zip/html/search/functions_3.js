var searchData=
[
  ['isvedimask_0',['IsvedimasK',['../studentas_8cpp.html#a5867a22892b5948f146b0d59ce59dc66',1,'IsvedimasK(const list&lt; Student &gt; &amp;kietiakai):&#160;studentas.cpp'],['../studentas_8h.html#ac7805be1f527dc3cba2b9cb621470b6b',1,'IsvedimasK(const std::list&lt; Student &gt; &amp;lst1):&#160;studentas.h']]],
  ['isvedimasv_1',['IsvedimasV',['../studentas_8cpp.html#a157c4783ad3e6bb346a7c5634092cc71',1,'IsvedimasV(const list&lt; Student &gt; &amp;vargsiukai):&#160;studentas.cpp'],['../studentas_8h.html#ac89afbf4521390ccd7b0f19592f5dc00',1,'IsvedimasV(const std::list&lt; Student &gt; &amp;vargsiukai):&#160;studentas.h']]],
  ['ivedimas_2',['ivedimas',['../studentas_8cpp.html#a55fec852690c7fdb1b9334d973bb66d0',1,'ivedimas(Student &amp;stud, bool generate):&#160;studentas.cpp'],['../studentas_8h.html#ae1070814d4dc65fdbf729c94da71df5e',1,'ivedimas(Student &amp;lok, bool generate):&#160;studentas.cpp']]]
];
