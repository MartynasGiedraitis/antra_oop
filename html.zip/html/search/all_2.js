var searchData=
[
  ['gen_0',['gen',['../studentas_8cpp.html#a374a9a7de3fd00dceacc5de8a654c087',1,'studentas.cpp']]],
  ['generavimas_1',['generavimas',['../studentas_8cpp.html#afc710f4b89c04d87a3835fa69fad0d99',1,'generavimas(int pazymiuSk):&#160;studentas.cpp'],['../studentas_8h.html#afc710f4b89c04d87a3835fa69fad0d99',1,'generavimas(int pazymiuSk):&#160;studentas.cpp']]],
  ['getelapsedtime_2',['getElapsedTime',['../class_chrono_timer.html#a3306f391019612434f7f63bd1319a256',1,'ChronoTimer']]],
  ['getmed_3',['getMed',['../class_student.html#af599b2d1956941b702497fec9b05a7bc',1,'Student']]],
  ['getnd_4',['getND',['../class_student.html#a96cc11285fa4bb107eb8c55ecefdeb2e',1,'Student']]],
  ['getvid_5',['getVid',['../class_student.html#a7e27173e1f4f32ae4a51ddc5d1c17a0e',1,'Student']]]
];
