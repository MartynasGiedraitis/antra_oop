var searchData=
[
  ['pavarde_0',['pavarde',['../class_zmogus.html#ac7302fa486c7c9f709576819eb2daa06',1,'Zmogus']]],
  ['pavarde_5f_1',['pavarde_',['../class_zmogus.html#a85cd6103a5f887059263d15413a3f081',1,'Zmogus']]],
  ['printinfo_2',['printInfo',['../class_zmogus.html#a182ed334d32f5ff9c520e159084669a3',1,'Zmogus::printInfo()'],['../class_student.html#ac0aa13639e0164b834366f3a303ce59d',1,'Student::printInfo()']]]
];
