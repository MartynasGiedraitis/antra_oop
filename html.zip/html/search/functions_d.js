var searchData=
[
  ['_7estudent_0',['~Student',['../class_student.html#a54a8ea060d6cd04222c3a2f89829f105',1,'Student']]],
  ['_7ezmogus_1',['~Zmogus',['../class_zmogus.html#ac5615bf607a8f2f1b303ffa04328d24d',1,'Zmogus']]]
];
