var searchData=
[
  ['tikrinam_0',['tikrinam',['../studentas_8cpp.html#a13cb4a3dcbe160e25605dee16fa5a0e2',1,'tikrinam(string &amp;fileName):&#160;studentas.cpp'],['../studentas_8h.html#a13cb4a3dcbe160e25605dee16fa5a0e2',1,'tikrinam(string &amp;fileName):&#160;studentas.cpp']]]
];
