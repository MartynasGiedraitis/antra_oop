var searchData=
[
  ['setegz_0',['setEgz',['../class_student.html#ad6203761b49aaaa9a5859b6fb24a7afb',1,'Student']]],
  ['setnd_1',['setND',['../class_student.html#a6b9fc6e2491c4cce840d2cbfde818aef',1,'Student']]],
  ['setpavarde_2',['setPavarde',['../class_student.html#a180cba635e0f8c70bbda4d58a1bb289f',1,'Student']]],
  ['setvardas_3',['setVardas',['../class_student.html#a70d9f1a217b86997395812567135401d',1,'Student']]],
  ['skaiciuotividurki_4',['skaiciuotiVidurki',['../class_student.html#a65784b398924ee5f482492f8928c8697',1,'Student']]],
  ['skaitymas_5',['skaitymas',['../class_student.html#ad05a6e0d244c711183063eb12f3e62ff',1,'Student::skaitymas()'],['../studentas_8h.html#a33d89c59d2126ef31316de3c9a4e2445',1,'skaitymas(std::ifstream &amp;file):&#160;studentas.h']]],
  ['skirstymas_6',['skirstymas',['../studentas_8cpp.html#a7e803d3afed1f81471e5fd28dab6cfb7',1,'skirstymas(list&lt; Student &gt; &amp;lst1, list&lt; Student &gt; &amp;vargsiukai):&#160;studentas.cpp'],['../studentas_8h.html#abb9614d94aa352ef7943f114cf57e031',1,'skirstymas(std::list&lt; Student &gt; &amp;lst1, std::list&lt; Student &gt; &amp;vargsiukai):&#160;studentas.h']]],
  ['student_7',['Student',['../class_student.html#af9168cedbfa5565cf0b20c1a9d3f5c9d',1,'Student::Student()'],['../class_student.html#a938f86d3f8d1e1ab0f4a420bb0390c6a',1,'Student::Student(std::ifstream &amp;file)'],['../class_student.html#ae92e23af2dc783eb5c4c821affbb9ce0',1,'Student::Student(const string &amp;vardas, const string &amp;pavarde, int egz, const vector&lt; int &gt; &amp;ND)'],['../class_student.html#a05b37ffb050ddb039db63a8764d790cb',1,'Student::Student(const Student &amp;other)']]]
];
